import axios from "axios"// usiamo al post di fetch
import {TOKEN} from './config';

function getMoviesPlaying(){
    return axios.get('https://api.themoviedb.org/3/movie/now_playing?language=it-IT',{
        headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    }) //importiamo il link

}

function getMoviesUpComing(){
     return axios.get('https://api.themoviedb.org/3/movie/upcoming?language=it-IT',{
        headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    }) //importiamo il link
}

function getMoviesTopRated(){
    return axios.get("https://api.themoviedb.org/3/movie/top_rated?language=it-IT",{
         headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    })
}

function getMovies(page){
    return axios.get("https://api.themoviedb.org/3/discover/movie?language=it-IT&page=" + page,{
        headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    })
}

function getMoviesByPeople(idPeople, page){    //PASSAGGIO UNO. PARTIAMO DALLA FUNZIONE CON LA PARTE FINALE DA CERCARE
    return axios.get("https://api.themoviedb.org/3/discover/movie?language=it-IT&with_cast" + idPeople + "&page="+page,{
          headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    })
}
function getMovie(id){
    return axios.get("https://api.themoviedb.org/3/movie/"+id+"?language=it-IT", {
        headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    })
        
    
}
function getCasting(id){
    return axios.get("https://api.themoviedb.org/3/movie/"+id+"/credits?language=it-IT", {
        headers : {
            "Authorization" : "Bearer " + TOKEN
        }
    })
        
    
}




export default{
    getMoviesPlaying,
    getMoviesUpComing,
    getMoviesTopRated,
    getMovies,
    getMoviesByPeople,
    getMovie,
    getCasting

}