import { Carousel } from "react-bootstrap";

const MoviesCarousel = ({title, movies}) => {
    return <>
     <h2>{title}</h2>
            <Carousel className="col-6">
                {movies.map((movies) => {
                    return <Carousel.Item key={movies.id}>
                        <img className="block w-100" src={"https://image.tmdb.org/t/p/original" + movies.backdrop_path}></img>
                        <Carousel.Caption>
                            <h2>{movies.title}</h2>
                        </Carousel.Caption>
                    </Carousel.Item>
                })}

            </Carousel>
    
    
    </>;
}

export default MoviesCarousel;